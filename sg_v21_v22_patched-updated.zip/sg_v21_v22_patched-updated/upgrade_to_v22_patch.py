import os, re, sys, json, shutil, textwrap
from pathlib import Path

BANNER = r"""
SG Vendor Cyber Maturity — v2.2 Patch
=====================================
Applies ALL requested fixes:

1) Dashboard charts smaller + Overall Maturity colored + legend (Very Poor=Red, Poor=Orange,
   Medium=Amber, Mature=Green, Very Mature=Blue)
2) Dashboard table: replace "Service Provided" column with a "Comment" text box that autosaves to
   /data/comments.json (per vendor + question)
3) Thank-You page shows a summary of uploaded evidence (grouped by Domain/Subdomain/Document)
4) Evidence filters: ensure domains "Change and Release Management", "Cloud", and "AI" appear even
   if their subdomains are absent (Domain-level upload row provided)
5) Dashboard Compliance is color-coded (Green/Amber/Red)

This script clones your source folder to <name>_v22_patched and updates files in the clone.
"""

ALWAYS_DOMAINS = [
    "Change and Release Management",
    "Cloud",
    "AI",
]

def die(msg):
    print("❌ " + msg)
    sys.exit(1)

def read(p): return Path(p).read_text(encoding="utf-8")
def write(p, s):
    Path(p).parent.mkdir(parents=True, exist_ok=True)
    Path(p).write_text(s, encoding="utf-8")

def copy_tree(src, dst):
    if Path(dst).exists():
        shutil.rmtree(dst)
    shutil.copytree(src, dst)

def patched_name(src_dir: str) -> str:
    p = Path(src_dir)
    name = p.name
    return f"{name}_v22_patched"

def ensure_comments_api(app_code: str) -> str:
    """Add /api/comment/<vendor_id> POST endpoint and comments loading in dashboard."""
    # 1) Ensure DATA paths declared (COMMENTS file)
    if "COMMENTS =" not in app_code:
        app_code = re.sub(
            r"(RESP_DIR\s*=\s*BASE\s*/\s*\"responses\"\s*\n)",
            r"\1COMMENTS = DATA / \"comments.json\"\n",
            app_code
        )

    # 2) Add helper loaders if missing
    if "def jload(" not in app_code:
        # Should already exist, but keep safe
        pass

    # 3) Add /api/comment route
    if "@app.post(\"/api/comment/" not in app_code and "@app.route(\"/api/comment/" not in app_code:
        inject = textwrap.dedent(r"""
        @app.post("/api/comment/<vendor_id>")
        def save_comment(vendor_id):
            qid = request.form.get("qid", "").strip()
            text = request.form.get("text", "").strip()
            if not qid:
                return jsonify({"ok": False, "message": "Missing qid"}), 400
            data = jload(COMMENTS, {})
            data.setdefault(vendor_id, {})[qid] = text
            jdump(COMMENTS, data)
            return jsonify({"ok": True})
        """)
        # Insert before if __name__ == "__main__"
        app_code = app_code.replace('if __name__ == "__main__":', inject + '\n\nif __name__ == "__main__":')

    # 4) In dashboard(), load comments and attach per row
    dash_re = re.compile(r"@app\.route\(\"/dashboard\"\)[\s\S]+?def\s+dashboard\(\):([\s\S]+?)\n@app\.route", re.M)
    m = dash_re.search(app_code)
    if m:
        body = m.group(1)
        if "comments =" not in body:
            # Load comments near top of function
            body2 = re.sub(
                r"(\s*vendor_id\s*=\s*request\.args\.get\([^\)]*\)\s*[\r\n]+)",
                r"\1    comments = jload(COMMENTS, {})\n",
                body
            )
            # Attach comment on each table row (after row append)
            body2 = body2.replace(
                "table.append({\"domain\": q[\"domain\"], \"subdomain\": q[\"subdomain\"], \"text\": q[\"text\"], \"answer\": ans, \"compliance\": comp, \"evidence\": ev, \"services\": []})",
                "table.append({\"domain\": q[\"domain\"], \"subdomain\": q[\"subdomain\"], \"text\": q[\"text\"], \"answer\": ans, \"compliance\": comp, \"evidence\": ev, \"comment\": comments.get(vendor_id, {}).get(q[\"id\"], \"\"), \"qid\": q[\"id\"]})"
            )
            app_code = app_code[:m.start(1)] + body2 + app_code[m.end(1):]

    return app_code

def patch_submit_thankyou(app_code: str) -> str:
    """Pass evidence summary to thank_you.html."""
    # In submit_form(), pass evidence list to template
    patt = r"return render_template\(\"thank_you\.html\"\)"
    if re.search(patt, app_code):
        app_code = re.sub(
            patt,
            'return render_template("thank_you.html", evidence_summary=evidence_saved)',
            app_code
        )
    return app_code

def patch_vendor_form_always_domains(app_code: str) -> str:
    """Ensure ALWAYS_DOMAINS appear even if missing, create a 'General' subdomain row when none."""
    vend_form_re = re.compile(r"def\s+vendor_form\(token\):([\s\S]+?)@app\.post\(\"/api/autosave", re.M)
    m = vend_form_re.search(app_code)
    if not m: return app_code
    body = m.group(1)
    # Add code after evidence = jload(EVIDENCE, {})
    if "evidence=jload(EVIDENCE" in body or "evidence = jload(EVIDENCE" in body:
        body2 = re.sub(
            r"(evidence\s*=\s*jload\(EVIDENCE,\s*\{\}\))",
            r"""\\1
    # v2.2: ensure required domains exist even if docx lacks them
    for _dom in %r:
        evidence.setdefault(_dom, {})
        if not evidence[_dom]:
            evidence[_dom] = {"General": []}
    """ % ALWAYS_DOMAINS,
            body
        )
        app_code = app_code[:m.start(1)] + body2 + app_code[m.end(1):]
    return app_code

def patch_dashboard_html(pth: Path):
    s = read(pth)

    # 1) Smaller chart containers + colored Overall Maturity + legend
    # Replace the "overall" card to color by summary.maturity_color and reduce headings
    s = s.replace(
        '<div class="p-4 rounded-xl shadow border">\n      <div class="text-sm text-gray-500 mb-1">Overall Maturity</div>\n      <div class="text-3xl font-bold">{{ summary.maturity }}</div>\n      <div class="text-sm text-gray-600">Score: {{ summary.overall_pct }}%</div>\n    </div>',
        '<div class="p-4 rounded-xl shadow border" style="border-color:#e5e7eb;background:rgba(0,0,0,0.02)">\n      <div class="text-xs text-gray-600 mb-1">Overall Maturity</div>\n      <div class="text-xl font-semibold" style="color: {{ summary.maturity_color or \'#111\' }};">{{ summary.maturity }}</div>\n      <div class="text-xs text-gray-600">Score: {{ summary.overall_pct }}%</div>\n    </div>'
    )
    # Shrink canvases via fixed heights
    s = s.replace('<canvas id="radar"></canvas>', '<canvas id="radar" style="max-height:260px;"></canvas>')
    s = s.replace('<canvas id="bars"></canvas>', '<canvas id="bars" style="max-height:220px;"></canvas>')

    # Add legend under bars card (if not already)
    if "Maturity Legend" not in s:
        s = s.replace(
            '<div class="p-4 rounded-xl shadow border mb-6">\n    <div class="text-sm font-semibold mb-2">Domain Level Score</div>\n    <canvas id="bars"></canvas>\n  </div>',
            '<div class="p-4 rounded-xl shadow border mb-6">\n    <div class="text-sm font-semibold mb-2">Domain Level Score</div>\n    <canvas id="bars" style="max-height:220px;"></canvas>\n    <div class="mt-3 text-xs text-gray-600">\n      <span class="mr-4"><b style="color:#E30613">■</b> Very Poor</span>\n      <span class="mr-4"><b style="color:orange">■</b> Poor</span>\n      <span class="mr-4"><b style="color:#ffbf00">■</b> Medium</span>\n      <span class="mr-4"><b style="color:green">■</b> Mature</span>\n      <span class="mr-4"><b style="color:blue">■</b> Very Mature</span>\n    </div>\n  </div>'
        )

    # 2) Replace "Service Provided" column with Comment text box + autosave
    s = s.replace('Service Provided', 'Comment')
    # header count already 7 cols; keep same
    # table row cell replacement: replace services display with a textbox bound to autosave
    s = s.replace(
        '{{ ", ".join(row.services or []) }}',
        '<input type="text" class="border rounded p-1 w-48 text-xs" value="{{ row.comment or \'\' }}" data-qid="{{ row.qid }}" data-vid="{{ vendor_id }}" oninput="debouncedCommentSave(this)" placeholder="Type comment…" />'
    )

    # 5) Compliance colored cell
    s = s.replace('{{ row.compliance }}', '<span class="{% if row.compliance == \'Compliant\' %}text-green-700{% elif row.compliance == \'Partially Compliant\' %}text-yellow-700{% elif row.compliance == \'Non-Compliant\' %}text-red-700{% endif %}">{{ row.compliance }}</span>')

    # Inject small JS (debounce + POST save)
    if "debouncedCommentSave" not in s:
        js = textwrap.dedent("""
        <script>
        let _commentTimer = null;
        function debouncedCommentSave(el){
          if(_commentTimer) clearTimeout(_commentTimer);
          _commentTimer = setTimeout(async ()=>{
            const qid = el.dataset.qid, vid = el.dataset.vid, text = el.value || "";
            const fd = new FormData();
            fd.append("qid", qid);
            fd.append("text", text);
            await fetch(`/api/comment/${vid}`, { method: "POST", body: fd });
          }, 800);
        }
        </script>
        """).strip()
        s = s.replace("</body>", js + "\n</body>")

    write(pth, s)

def patch_form_html(pth: Path):
    s = read(pth)
    # 4) Evidence domain handling is done server-side; nothing required here
    # Keep as-is
    write(pth, s)

def patch_thankyou_html(pth: Path):
    s = read(pth)
    # 3) Show evidence summary if present
    if "evidence_summary" not in s:
        block = textwrap.dedent("""
        {% if evidence_summary and evidence_summary|length %}
        <div class="max-w-md mx-auto mt-4 p-4 border rounded-xl bg-white">
          <div class="text-sm font-semibold mb-2">Documents you submitted</div>
          <ul class="text-sm list-disc ml-5">
          {% for dom, subs in evidence_summary.items() %}
            {% for sub, names in subs.items() %}
              {% for name in names %}
                <li><b>{{ dom }}</b> — {{ sub }} — {{ name }}</li>
              {% endfor %}
            {% endfor %}
          {% endfor %}
          </ul>
        </div>
        {% endif %}
        """).strip()
        s = s.replace('</div>\n{% endblock %}', block + '\n</div>\n{% endblock %}')
    write(pth, s)

def patch_app(app_path: Path):
    code = read(app_path)

    # Add COMMENTS store + /api/comment + dashboard wiring
    code = ensure_comments_api(code)

    # Pass evidence summary to thank-you
    code = patch_submit_thankyou(code)

    # Ensure ALWAYS_DOMAINS in vendor_form() evidence dict
    code = patch_vendor_form_always_domains(code)

    write(app_path, code)

def main():
    print(BANNER)
    if len(sys.argv) < 2:
        die("Usage: python upgrade_to_v22_patch.py <SOURCE_FOLDER>\nExample: python upgrade_to_v22_patch.py sg_v21")
    src = Path(sys.argv[1]).resolve()
    if not src.is_dir():
        die(f"Folder not found: {src}")

    dst = src.parent / patched_name(src.name)
    print(f"📁 Cloning '{src.name}'  →  '{dst.name}' ...")
    copy_tree(src, dst)

    # Locate files
    app_py = dst / "app_v21.py"
    dash_html = dst / "templates" / "dashboard.html"
    form_html = dst / "templates" / "form.html"
    thanks_html = dst / "templates" / "thank_you.html"

    for p in [app_py, dash_html, form_html, thanks_html]:
        if not p.exists():
            die(f"Required file missing in clone: {p}")

    print("🔧 Patching app_v21.py ...")
    patch_app(app_py)

    print("🎨 Patching templates/dashboard.html ...")
    patch_dashboard_html(dash_html)

    print("🧾 Patching templates/form.html ...")
    patch_form_html(form_html)

    print("🙏 Patching templates/thank_you.html ...")
    patch_thankyou_html(thanks_html)

    print("\n✅ v2.2 patch complete.")
    print(f"Next steps:\n  cd {dst.name}\n  python app_v21.py\n  # Open http://localhost:8000\n")

if __name__ == "__main__":
    main()